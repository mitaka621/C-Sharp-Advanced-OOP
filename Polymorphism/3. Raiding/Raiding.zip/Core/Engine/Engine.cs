﻿using Raiding.Factories;
using Raiding.Factories.Interfaces;
using Raiding.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raiding.Core.Engine
{
    public class Engine : IEngine
    {
        private readonly ICollection<IBaseHero> heroes;
        IHeroFactory CreateHero;
        public Engine(IHeroFactory factory)
        {
            heroes=new List<IBaseHero>();
            CreateHero= factory;
        }
        public void Run()
        {

            int n = int.Parse(Console.ReadLine());

            while(n>0)
            { 
                try
                {
                    string name = Console.ReadLine();

                    string type = Console.ReadLine();

                    heroes.Add(CreateHero.Create(type, name));
                    n--;
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (Exception)
                {

                    throw;
                }
               
            }

            foreach (var item in heroes)
            {
                Console.WriteLine(item.CastAbility()); 
            }
            int bossPower = int.Parse(Console.ReadLine());

            if (heroes.Sum(x=>x.Power)>= bossPower)
                Console.WriteLine("Victory!");
            else
                Console.WriteLine("Defeat...");
        }
    }
}
