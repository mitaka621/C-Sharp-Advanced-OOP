﻿internal interface IFarmFactory
{
}